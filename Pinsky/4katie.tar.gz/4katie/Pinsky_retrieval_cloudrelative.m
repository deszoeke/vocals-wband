function [Vg,W,Ustd,a]=Pinsky_retrieval_cloudrelative(V,Z,Zbin,Vgbin,Ustdbin,rho,h,htop,hthick)
% [Vg,W,Vgbin,Ustdbin,a]=Pinsky_retrieval(V,Z,Zbin,Ustdbin,rho,h,htop,hthick)
% perform the Pinsky et al. (2010) statistical velocity retrieval from radar Doppler velocity
% 
% INPUTS
% V     Doppler velocity
% Z     Reflectivity
% Zbin  reflectivity bins for computing mean and variance of V [default -40:0.25:10]
% Vgbin   lookup table for Vg(Z,h-htop)=phi(Z)
% Ustdbin   lookup table for theta(Z,h-htop)=<U'^2>_Z^1/2
% rho   specified height-dependent correlation of W and Vg'    [default 0]
% h     range height (m)
% htop  cloud top height (m)
% hthick cloud thickness (m) [not used]
%
% OUTPUTS
% Vg    Doppler estimate of mean settling velocity
% W     air velocity retrieval
% Ustd  standard deviation of residual velocity U=V-Vgbin(Z)
%
% NOTES
% Vgprime=V-Vg-W
% Bin averages are used rather than 6th order polynomial fit because the fit is not statistically stable.

% Simon de Szoeke 2012 December 28

rho=rho(:)'; % row vector

% radar range gate index of cloud top
nh=length(h);
iihtop=isfinite(htop);
itop=ones(size(htop));
itop(iihtop)=interp1(h,1:nh,htop(iihtop),'nearest');
itop(~iihtop)=1; % kluge for undefined cloud tops
%jtop=91; % the index of the cloud top once shifted
shift=-90:10;
nhshift=length(shift);

% mean and variance by reflectivity bin
% Ustdbin is Pinsky's theta(Z)
% nbin=zeros(length(Zbin),nh);
% indx=zeros(size(Z));
Zshift=zeros(size(Z,1),nhshift);
%indx=zeros(size(Z));

% indices for input (source) array
ii=max(1,min(nh,bsxfun(@plus,itop,shift)));
% bsxfun does addition of column and row vectors with matix mult. rules

% shift Z,V so the cloud top is always at index 91
for ti=1:size(Z,1)
    Zshift(ti,:)=Z(ti,ii(ti,:));
%     Vshift(ti,:)=V(ti,ii(ti,:));
end

[Vgshift,Ustdshift,Wbarupshift]=deal(NaN(size(Zshift)));
[Vg,Ustd,Wbarup]=deal(NaN(size(Z)));
for hi=1:nhshift
    % lookup Vg and Ustd=theta(Z(h,t)) for all hrel,t [cloud-top rel. coordinate]
    indx=floor(interp1(Zbin,1:length(Zbin),Zshift(:,hi),'linear'));
    indx(isnan(indx))=length(Zbin);
    indx(indx==0)=length(Zbin);
    Vgshift(:,hi)=min(0,Vgbin(indx,hi));     % enforce Vg<=0
    Wbarupshift(:,hi)=max(0,Vgbin(indx,hi)); % mean upward "fall" velocity
    Ustdshift(:,hi)=Ustdbin(indx,hi);
end
Vgshift(isnan(Ustdshift))=NaN;
% consider attributing some of this Vg to Wbar(Z).

% shift back to standard height coordinate using ii
for ti=1:size(Z,1)
    Vg(ti,ii(ti,:))=Vgshift(ti,:);
    Ustd(ti,ii(ti,:))=Ustdshift(ti,:);
    Wbarup(ti,ii(ti,:))=Wbarupshift(ti,:);
end

% residual velocity
U=V-Vg;

% linear weighted attribution of residual to W and Vg'
S1=nanmean(1./Ustd);
S2=nanmean(1./(Ustd.*Ustd));

% for correlation rho=<WVg'>=0
a0=S1./S2;
% general case for zero or nonzero correlation rho
%a0=S1./S2-rho./S2.*sqrt((S2-S1.*S1)./(1-rho.*rho));
a=repmat(a0,[size(V,1),1])./Ustd;
% separate W and Vgprime from U
W=a.*U;
% Vgprime=(1-a).*U;

% Vgprime=U-W=V-Vg-W;
return